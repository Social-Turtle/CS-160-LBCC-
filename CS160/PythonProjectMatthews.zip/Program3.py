print("Hello! I am your friendly neighborhood averaging robot, cleverly named AverageBot!\nThough you may refer to me as Ava if you'd prefer!")
print("I am capable of averaging any three integers, no matter how great! Let me show you!")

num_one = int(input("Please enter your first integer here! \n"))
num_two = int(input("Wow, what a great integer! Another, please! \n"))
num_three = int(input("You're a natural! All we need is one more! \n"))

print("\n*does some fancy computer mental math...*\n")

print("You entered:" , num_one , "," , num_two , ", and" , num_three , "which averages to a value of " , (num_one + num_two + num_three)/3 ,"!",)