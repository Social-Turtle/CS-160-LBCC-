print("Hello, and welcome to the odd number 22 to 44 counter!")
# a pleasant greeting to improve user experience

i = 22 
#defining our numeric variable, i

for i in range(22,45,2): #count from 22 to 44 with a step of 2
    print(i) #printing our number

