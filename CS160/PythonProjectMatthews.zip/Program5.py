import random
dice_one = random.randrange(1,7) # dice roll 1 to 6
dice_two = random.randrange(1,7)

print("Dice one rolled a ", dice_one, "!") # inform user of dice 1's value
print("Dice two rolled a ", dice_two, "!") # inform user of dice 2's value

print("Thats a total of ", dice_one + dice_two, "!") # inform user of dice sum.