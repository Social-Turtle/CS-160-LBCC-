print("Hello, and welcome to the odd number 15 to 45 counter!")
# a pleasant greeting to improve user experience

i = 15
#defining our numeric variable, i

while i<=45: #count from 22 to 44 with a step of 2
    print(i) #printing our number
    i += 2